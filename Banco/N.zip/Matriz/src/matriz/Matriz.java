
package matriz;

import java.util.Scanner;


public class Matriz {

  
    public static void main(String[] args) {
        
     /* int [][] matriz = {{1,2,2},{4,5,6},{7,8,9}};
        for(int i=0; i<matriz.length; i++){
        for (int j=0; j<matriz[1].length; j++) {
            System.out.print(matriz[i][j]);
        }
        System.out.println();
    } 
      */
     
       /* int matriz[][]=new int[3][3];
        Scanner num = new Scanner(System.in);
        for(int i=0; i<3; i++){ //i=1
        for (int j=0; j<3; j++)//j=1
        {
            System.out.println("Introdusca numeros: ");
            int nume=num.nextInt ();
            matriz[i][j]=nume;
        }
    } 
      System.out.println("Imprime numeros de la matriz: ");
      for(int i=0;i<3;i++){
          
          System.out.println("\n");
          
          for(int j=0;j<3;j++){
              System.out.print
        (matriz[i][j]+"\t");
      }
     
      }
      */
        int[] matriz=new int [10];
        int aux=1, valori,valf;
        Scanner scn = new Scanner(System.in);
        System.out.print("Valor inicial: ");
        valori=scn.nextInt();
        System.out.print("Valor final: ");
        valf=scn.nextInt();
        do{
            for(int i=0; i<10; i++)
              matriz[i]= valori * aux++;
            { 
            for (int i=0; i<10; i++)    
              {
            System.out.print("\t{"+matriz[i]+"]");
              }
            valori++;
            aux=1;
            System.out.println();
      
            }
        }while (valori<=valf);
    
    }
}