
package secuencias;


public class SECUENCIAS {

   
    public static void main(String[] args) {
        int a=2;
        int b=2;
        int j=0;
        String arregloi[]={"D","I","O","X"};
        
      
       int serie[]=new int[5];
              
       System.out.print("2  A  ");
       for(int i=1; i<serie.length;i++){
           serie[i]=a*b;
           b=serie[i];
           a+=2;
       }
       for(int i=1; i<serie.length;i++){
           System.out.print(serie[i]+"  "+arregloi[j]+"  ");
           j++;
       }
       
    }
}
