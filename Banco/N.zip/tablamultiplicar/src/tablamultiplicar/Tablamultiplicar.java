
package tablamultiplicar;

public class Tablamultiplicar {

    
    public static void main(String[] args) {
        int i,j;
        int[][] matriz = new int[11][11];

        for (i=0 ; i < matriz.length ; i++){
          
            matriz[i][0]=i;
            matriz[0][i]=i;
        }
       
        for (i=1 ; i < matriz.length ; i++){
            for (j=1 ; j < matriz[i].length ; j++){
               matriz[i][j]=i*j; 
            }
        }
        
        for (i=0; i < matriz.length ; i++){
            for (j=0 ; j < matriz[i].length ; j++){
                System.out.print("\t" + matriz[i][j]);
            }
            System.out.println();
          
          }
    }
    
}
