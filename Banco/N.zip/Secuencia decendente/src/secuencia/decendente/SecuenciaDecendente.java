
package secuencia.decendente;

import java.util.Scanner;


public class SecuenciaDecendente {

    public static void main(String[] args) {
    Scanner entrada = new Scanner(System.in);
        int num =500;
        
        for (int i = 0; i < 45 ; i++) {
            num =  num-11; 
            System.out.println("\t"+"Numero = "+ num);
        }

    }
    
}
