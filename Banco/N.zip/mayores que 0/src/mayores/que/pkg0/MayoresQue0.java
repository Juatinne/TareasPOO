
package mayores.que.pkg0;

import java.util.Scanner;


public class MayoresQue0 {

    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        int cont = 0,n=0;
        do{
            if(n>=0){
                System.out.println("Ingrese un valor");
                n=ent.nextInt();
                if(n>=0){
                    cont++;
                }      
            }else{
                System.out.println("No valido");
                System.out.println("Ingres un valor");
                n=ent.nextInt();
                if(n>=0){
                    cont++;
                }
            }
        }while(cont!=5);
    }
    
}
