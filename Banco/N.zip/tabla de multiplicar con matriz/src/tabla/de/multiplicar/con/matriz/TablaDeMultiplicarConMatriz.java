
package tabla.de.multiplicar.con.matriz;

import java.util.Scanner;

public class TablaDeMultiplicarConMatriz {

    
    public static void main(String[] args) {
     
        int [] matriz=new int [10];
        int aux=1, valori=1,valf=10;
        Scanner scn = new Scanner(System.in);
        do{
            for(int i=0; i<10; i++)
              matriz[i]= valori * aux++;
            { 
            for (int i=0; i<10; i++)    
              {
            System.out.print("\t { "+matriz[i]+" ]");
              }
            valori++;
            aux=1;
            System.out.println();
      
            }
        }while (valori<=valf);
    }
    
}
