
package pedirnumero;

import java.util.Scanner;


public class Pedirnumero {

   
    public static void main(String[] args) {

     Scanner entrada = new Scanner(System.in);

        int num = 0;

        int suma = 0;

        //numero = entrada.nextInt();
        while (num>= -0) {
            System.out.println("Ingrese numero");
            num = entrada.nextInt();
            if (num >= -0) {
                suma += num;
            }

        }
        System.out.println("La Suma es: " + suma);

        System.out.println("Numero negativo ingresado " + num);

    }
    
}
