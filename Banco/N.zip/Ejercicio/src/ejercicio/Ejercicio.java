
package ejercicio;

import java.util.Scanner;


public class Ejercicio {


    public static void main(String[] args) {
       
        int i,j;
        int[][] matriz = new int[10][10];
 
        //Relleno la primera fila y la primera columna de la matriz
        for (i=0 ; i < matriz.length ; i++){
            //cambia fila pero no la columna
            matriz[i][0]=i;
            //cambia la columna pero no la fila
            matriz[0][i]=i;
        }
        
        //Ahora relleno el resto de la matriz
        for (i=1 ; i < matriz.length ; i++){
            for (j=1 ; j < matriz[i].length ; j++){
               matriz[i][j]=i*j; 
            }
        }
        
        for (i=0; i < matriz.length ; i++){
            for (j=0 ; j < matriz[i].length ; j++){
                System.out.print("\t" + matriz[i][j]);
            }
            System.out.println();
          
          }
    /*Scanner entrada = new Scanner(System.in);

        String producto[] = new String[2];
        double precios[] = new double[2];

        for (int i = 0; i < producto.length; i++) {

            System.out.println("Ingrese producto " + i);
            producto[i] = entrada.next();
        }

        for (int i = 0; i < precios.length; i++) {
            System.out.println("Ingrese precio " + i);
            precios[i] = entrada.nextDouble();
        }

        System.out.println("INICIA EL FOR");
        for (int i = 0; i < precios.length; i++) {
            System.out.println("Producto: " + producto[i]
        + "-->Precio " + precios[i] );
        }*/
    }
    
    
}
