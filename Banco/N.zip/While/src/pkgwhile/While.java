
package pkgwhile;

import javax.swing.JOptionPane;


public class While {

    public static void main(String[] args) {
      int num;
      int i=1;
      int suma=0;
       
      while (i>-0){
          num=Integer.parseInt(JOptionPane.showInputDialog ("Ingrese un valor: "));
          suma=num+suma;
          i=i+1;
          
        }
      JOptionPane.showMessageDialog(null,"La suma de los numeros ingresados es: "+suma);  
    }
}     